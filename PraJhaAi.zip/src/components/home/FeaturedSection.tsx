import React from 'react';
import { Tool } from '../../types';
import ToolGrid from '../tools/ToolGrid';

interface FeaturedSectionProps {
  tools: Tool[];
}

const FeaturedSection: React.FC<FeaturedSectionProps> = ({ tools }) => {
  const featuredTools = tools.filter(tool => tool.featured);
  
  return (
    <div className="py-8">
      <ToolGrid 
        tools={featuredTools} 
        title="Featured AI Tools" 
        description="Our curated selection of the most powerful and innovative AI tools available today"
      />
    </div>
  );
};

export default FeaturedSection;