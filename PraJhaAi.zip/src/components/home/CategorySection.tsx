import React from 'react';
import { ChevronRight, Lock } from 'lucide-react';
import { Category } from '../../types';
import { getCategoryIcon } from '../../data/mockData';

interface CategorySectionProps {
  categories: Category[];
  onCategoryClick: (categoryId: string) => void;
  isAuthenticated: boolean;
}

const CategorySection: React.FC<CategorySectionProps> = ({ 
  categories, 
  onCategoryClick,
  isAuthenticated 
}) => {
  return (
    <div className="container mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold mb-2 text-white">Browse by Category</h2>
      <p className="text-gray-400 mb-8 max-w-2xl">
        Explore AI tools organized across various specialized categories
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((category) => {
          const IconComponent = getCategoryIcon(category.icon);
          
          return (
            <button
              key={category.id}
              onClick={() => onCategoryClick(category.id)}
              className="text-left bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-cyan-500/50 hover:shadow-lg hover:shadow-cyan-500/10 transition-all group"
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-500/20 to-purple-500/20 flex items-center justify-center mr-4">
                  <IconComponent className="h-6 w-6 text-cyan-400" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white group-hover:text-cyan-400 transition-colors">
                    {category.name}
                  </h3>
                  <span className="text-sm text-gray-400">{category.count} tools</span>
                </div>
              </div>
              
              <p className="text-gray-400 mb-4">{category.description}</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-cyan-400 group-hover:translate-x-1 transition-transform">
                  <span className="text-sm font-medium">Explore</span>
                  <ChevronRight className="h-4 w-4 ml-1" />
                </div>
                
                {!isAuthenticated && (
                  <Lock className="h-4 w-4 text-gray-500" />
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default CategorySection;