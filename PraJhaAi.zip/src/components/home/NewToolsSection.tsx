import React from 'react';
import { Tool } from '../../types';
import ToolGrid from '../tools/ToolGrid';

interface NewToolsSectionProps {
  tools: Tool[];
}

const NewToolsSection: React.FC<NewToolsSectionProps> = ({ tools }) => {
  // Filter to show only new tools, or we could sort by launch date
  const newTools = tools.filter(tool => tool.isNew || new Date(tool.launchDate) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000));
  
  return (
    <div className="py-8 bg-slate-900/50">
      <ToolGrid 
        tools={newTools} 
        title="Newly Launched AI Tools" 
        description="The latest AI innovations that have just hit the market" 
      />
    </div>
  );
};

export default NewToolsSection;