import React from 'react';
import Header from './Header';
import Footer from './Footer';
import { useAuthStore } from '../../store/authStore';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { isAuthenticated } = useAuthStore();

  return (
    <div className="flex flex-col min-h-screen bg-slate-950 text-white">
      {isAuthenticated && <Header />}
      <main className={`flex-grow ${isAuthenticated ? 'pt-16' : ''}`}>{children}</main>
      {isAuthenticated && <Footer />}
    </div>
  );
};

export default Layout;