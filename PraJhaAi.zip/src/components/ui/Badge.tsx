import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  color?: 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'error';
}

const Badge: React.FC<BadgeProps> = ({ children, color = 'default' }) => {
  const colorClasses = {
    default: 'bg-slate-700 text-gray-300',
    primary: 'bg-cyan-500/20 text-cyan-400',
    secondary: 'bg-purple-500/20 text-purple-400',
    success: 'bg-green-500/20 text-green-400',
    warning: 'bg-amber-500/20 text-amber-400',
    error: 'bg-red-500/20 text-red-400',
  };

  return (
    <span
      className={`px-2 py-1 text-xs font-medium rounded-full ${colorClasses[color]}`}
    >
      {children}
    </span>
  );
};

export default Badge;