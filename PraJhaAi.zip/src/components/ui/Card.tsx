import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '' }) => {
  return (
    <div
      className={`bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl overflow-hidden shadow-lg hover:shadow-cyan-500/10 transition-all duration-300 ${className}`}
    >
      {children}
    </div>
  );
};

export default Card;