import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { User, AuthResponse } from '@supabase/supabase-js';

interface AuthState {
  user: User | null;
  loading: boolean;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signInWithPhone: (phone: string, password: string) => Promise<void>;
  signUpWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithPhone: (phone: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  setUser: (user: User | null) => void;
  isAuthenticated: boolean;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  isAuthenticated: false,

  signInWithEmail: async (email: string, password: string) => {
    const { error }: AuthResponse = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      if (error.message === 'Invalid login credentials') {
        throw new Error('Invalid email or password. Please try again.');
      }
      throw new Error(error.message);
    }
  },

  signInWithPhone: async (phone: string, password: string) => {
    const { error }: AuthResponse = await supabase.auth.signInWithPassword({
      phone,
      password,
    });

    if (error) {
      if (error.message === 'Invalid login credentials') {
        throw new Error('Invalid phone number or password. Please try again.');
      }
      throw new Error(error.message);
    }
  },

  signUpWithEmail: async (email: string, password: string) => {
    const { error }: AuthResponse = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });

    if (error) {
      if (error.message.includes('already registered')) {
        throw new Error('This email is already registered. Please sign in instead.');
      }
      throw new Error(error.message);
    }
  },

  signUpWithPhone: async (phone: string, password: string) => {
    const { error }: AuthResponse = await supabase.auth.signUp({
      phone,
      password,
    });

    if (error) {
      if (error.message.includes('already registered')) {
        throw new Error('This phone number is already registered. Please sign in instead.');
      }
      throw new Error(error.message);
    }
  },

  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    set({ user: null, isAuthenticated: false });
  },

  setUser: (user) => set({ 
    user, 
    loading: false,
    isAuthenticated: !!user 
  }),
}));