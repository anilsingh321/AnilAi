import React from 'react';
import { useParams } from 'react-router-dom';
import { mockTools, categories } from '../data/mockData';
import ToolGrid from '../components/tools/ToolGrid';

const CategoryPage: React.FC = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const category = categories.find(c => c.id === categoryId);
  const toolsInCategory = mockTools.filter(tool => tool.category === categoryId);

  if (!category) {
    return (
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-3xl font-bold text-white">Category not found</h1>
      </div>
    );
  }

  return (
    <div className="pt-24">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold mb-4 text-white">{category.name}</h1>
        <p className="text-gray-400 mb-8 max-w-2xl">{category.description}</p>
      </div>
      <ToolGrid 
        tools={toolsInCategory}
        title="Available Tools"
        description="Explore all the AI tools available in this category"
      />
    </div>
  );
};

export default CategoryPage;