import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Home from './pages/Home';
import CategoryPage from './pages/CategoryPage';
import { useAuthStore } from './store/authStore';
import { supabase } from './lib/supabase';
import AuthModal from './components/auth/AuthModal';
import { ArrowRight, Brain, Sparkles, Zap } from 'lucide-react';

function App() {
  const { setUser, isAuthenticated } = useAuthStore();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, [setUser]);

  return (
    <Router>
      <Layout>
        {isAuthenticated ? (
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/categories/:categoryId" element={<CategoryPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        ) : (
          <div className="min-h-screen">
            {/* Header with Auth Button */}
            <div className="fixed top-0 right-0 p-6 z-50">
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-full hover:opacity-90 transition flex items-center gap-2 shadow-lg shadow-cyan-500/20"
              >
                Sign In <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Hero Section */}
            <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
              {/* Background with parallax effect */}
              <div className="absolute inset-0">
                <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg')] bg-cover bg-fixed bg-center opacity-30">
                  <div className="absolute inset-0 bg-gradient-to-b from-slate-950/90 via-slate-950/80 to-slate-950" />
                </div>
                
                {/* Floating tech elements with enhanced animations */}
                <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-cyan-500/20 rounded-full blur-3xl animate-float-slow" />
                <div className="absolute top-1/3 right-1/4 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl animate-float-medium" />
                <div className="absolute bottom-1/4 left-1/3 w-40 h-40 bg-blue-500/20 rounded-full blur-3xl animate-float-fast" />
              </div>

              <div className="container mx-auto px-4 relative z-10">
                <div 
                  className={`text-center mb-16 transition-all duration-1000 transform ${
                    isVisible 
                      ? 'opacity-100 translate-y-0' 
                      : 'opacity-0 translate-y-10'
                  }`}
                >
                  <div className="relative inline-block mb-8">
                    <h1 className="text-6xl md:text-8xl font-bold leading-tight text-white drop-shadow-2xl">
                      Discover the Future of
                      <span className="block bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 text-transparent bg-clip-text animate-gradient">
                        AI Innovation
                      </span>
                    </h1>
                    <div className="absolute -inset-4 bg-gradient-to-r from-cyan-500 to-purple-500 opacity-20 blur-3xl -z-10" />
                  </div>
                  <p className="text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
                    Your gateway to the world's most advanced AI tools and technologies.
                    Join our platform to explore, compare, and utilize cutting-edge artificial intelligence solutions.
                  </p>
                  <button
                    onClick={() => setIsAuthModalOpen(true)}
                    className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-full hover:opacity-90 transition text-lg font-medium shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/40 transform hover:scale-105"
                  >
                    Get Started Now
                  </button>
                </div>

                {/* Features Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
                  <div className="bg-slate-800/50 backdrop-blur-sm p-8 rounded-xl border border-slate-700 hover:border-cyan-500/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/20">
                    <Brain className="w-12 h-12 text-cyan-400 mb-4" />
                    <h3 className="text-xl font-bold mb-2">AI Tools Directory</h3>
                    <p className="text-gray-400">
                      Access our comprehensive collection of AI tools across multiple categories.
                    </p>
                  </div>
                  <div className="bg-slate-800/50 backdrop-blur-sm p-8 rounded-xl border border-slate-700 hover:border-purple-500/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-purple-500/20">
                    <Sparkles className="w-12 h-12 text-purple-400 mb-4" />
                    <h3 className="text-xl font-bold mb-2">Expert Reviews</h3>
                    <p className="text-gray-400">
                      Get detailed insights and comparisons from AI experts and users.
                    </p>
                  </div>
                  <div className="bg-slate-800/50 backdrop-blur-sm p-8 rounded-xl border border-slate-700 hover:border-amber-500/50 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-amber-500/20">
                    <Zap className="w-12 h-12 text-amber-400 mb-4" />
                    <h3 className="text-xl font-bold mb-2">Latest Updates</h3>
                    <p className="text-gray-400">
                      Stay informed about new AI tools and industry developments.
                    </p>
                  </div>
                </div>

                {/* Featured Tools Preview */}
                <div className="text-center mb-16">
                  <h2 className="text-3xl font-bold mb-8">Featured AI Tools</h2>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    {[
                      {
                        image: "https://images.pexels.com/photos/8386423/pexels-photo-8386423.jpeg",
                        name: "AI Image Generation"
                      },
                      {
                        image: "https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg",
                        name: "Natural Language Processing"
                      },
                      {
                        image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg",
                        name: "Code Generation"
                      },
                      {
                        image: "https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg",
                        name: "Video Creation"
                      }
                    ].map((tool, index) => (
                      <div 
                        key={index}
                        className="relative group cursor-pointer overflow-hidden rounded-xl transform transition-all duration-300 hover:scale-105"
                        onClick={() => setIsAuthModalOpen(true)}
                      >
                        <img 
                          src={tool.image} 
                          alt={tool.name}
                          className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent flex items-end p-4">
                          <p className="text-white font-medium transform transition-transform duration-300 group-hover:translate-y-[-4px]">
                            {tool.name}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Call to Action */}
                <div className="text-center">
                  <p className="text-gray-400 mb-8">
                    Join thousands of professionals already using PrajhaAI
                  </p>
                  <button
                    onClick={() => setIsAuthModalOpen(true)}
                    className="px-8 py-3 bg-slate-800 text-white rounded-full hover:bg-slate-700 transition transform hover:scale-105"
                  >
                    Start Exploring
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
      </Layout>
    </Router>
  );
}

export default App;